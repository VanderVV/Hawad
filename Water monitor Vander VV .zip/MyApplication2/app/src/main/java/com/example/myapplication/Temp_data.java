package com.example.myapplication;

public class Temp_data {
    static String temp_data = "";
}
